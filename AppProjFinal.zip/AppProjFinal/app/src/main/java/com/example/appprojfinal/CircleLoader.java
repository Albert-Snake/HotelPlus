package com.example.appprojfinal;

import android.content.Context;

public class CircleLoader {

    private Context mContext;
    public CircleLoader(Context context) {

    }
}
